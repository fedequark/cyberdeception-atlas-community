# Changelog

All notable public research releases are documented here. Release identifiers describe the dataset and research artifacts independently from application package versions.

## 2026.09.2 — 18 September 2026

- Reconciled the active summaries and limitations of all full-text-labelled records so inherited abstract-level text is no longer presented as current.
- Disclosed that the 20 full-text syntheses used one reviewer and lack retained page anchors and independent adjudication.
- Added immutability guards, explicit release parameters, source-state metadata, publisher-metadata sensitivity views, and public reproducibility-package downloads.
- Reframed the HTTP pilot as a deterministic conformance test and regenerated its results manifest.
- Added a prospective independent reporting-schema study protocol and an IEEE-style whitepaper draft.

### Known limitations

- The corrective release does not retroactively create page anchors, dual review, or a complete historical screening ledger.
- The independent schema study has not enrolled participants and reports no outcomes.
- The source manifest records a dirty worktree because this release was built before the corrections were committed.
- A DOI has not been assigned.

## 2026.09 — 18 September 2026

- Froze 187 public source-linked records and 69 relationships using canonical JSON and SHA-256 checksums.
- Included 20 full-text reviews and 50 source-bounded critical readings.
- Added reproducible tables, figures, missingness analysis, source-host analysis, and evidence-depth sensitivity views.
- Published the prospective corpus protocol, codebook, exact discovery queries, and screening-ledger template.
- Added the isolated `http-decoy-pilot-v1` worked evaluation with baseline, raw observations, negative controls, latency measures, and explicit unmeasured outcomes.
- Applied MIT to project software and CC BY 4.0 to original data and documentation.
- Added citation and Zenodo deposition metadata.

### Known limitations

- Early editorial tranches lack a complete candidate and exclusion ledger, so this release is a curated corpus rather than a completed systematic review.
- Most records describe source or repository material rather than independent operational effectiveness.
- The worked evaluation validates the reporting workflow in loopback only; it is not production evidence.
- A DOI has not been assigned. The Zenodo metadata is prepared for a future public deposit.
